<footer>
    <div id="footer_wrap">
        <div id="contacts">
        <h5> Контакты </h5>
            <ul >
                <li id="phone"><a href="tel:+79831049306">+7 (983) 104-93-06</a></li>
                <li id="email"><a href="mailto:rewollo@gmail.com"> rewollo@gmail.com </a></li>
            </ul>
        </div>
        <div id="footer_nav">
            <h5> Меню </h5>
            <ul>
                <li><a href="../news.php">Новости</a></li>
                <li><a href="../articles.php">Статьи</a></li>
                <li><a href="../videos.php">Видео</a></li>
                <li><a href="../guides.php">Гайды</a></li>
            </ul>
        </div>
        <div id="social">
            <a href="https://vk.com/public214297543"><img src="../assets/icons/vk.png" alt="vk" style="
            width: 100px;
            height: 100px"></a>
        </div>
    </div>
    <hr style="max-width: 80vw; margin: auto">
    <h6 style="padding-left: 10%; max-width: 30%; margin: 30px auto"> InGame &copy; 2022 </h6>
</footer>